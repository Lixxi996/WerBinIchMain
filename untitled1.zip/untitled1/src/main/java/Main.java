

import java.io.*;
import java.util.Scanner;

public class Main {
    personarray[]
    questionarray[]

    public static void askQuestion(int x) throws IOException {
        System.out.println(reader.giveItAll(x,0));
        questionarray[x] = null;



    }



    public static void main(String[] args) throws IOException {
        int i = 0;
        boolean isGameOn = true;

        int x = reader.getRows();
        int y = reader.getCols();

        System.out.println(x);
        System.out.println(y);

        // Wenn wir eine Frage/Eigenschaft wollen
        for (i = 0; i < x; i++) {
            System.out.println(reader.giveItAll(i, 0));
        }
        // Wenn wir eine Person haben wollen
        for (i = 0; i < (y - 1); i++) {
            System.out.println(reader.giveItAll(0, i));
        }

        while (isGameOn) {
            askQuestion();
            System.out.println();
            Scanner scanner = new Scanner(System.in);
            int input = scanner.nextInt();

            if (input == 1) {
                for (i = 0; i < (y - 1); i++) {
                    if (reader.giveItAll(1, i) != "ja"){
                        personarray[i] = null;


                    }
                }



            }
        }









        //loop, der eine zeile liest, und dann mit der zeile einen neuen politiker erstellt
        //und im besten fall diesen politiker in ein array reinhaut


        /*while(true) {

            reader.splitIt(reader.readIt(), i);
            i++;
            zeilennummer++;
            if (reader.splitIt(reader.readIt(), i) == null) {
                break;
            }

         */


        // ist deine person männlich?
        // for each
        // if reader.readIt(i, j) == w;
        // boolean reader.readIt(xy) == false;



        /*String fileName = "";
        File file = new File(fileName);
        FileReader fr = new FileReader(file);
        BufferedReader br = new BufferedReader(fr);
        String line;
        while((line = br.readLine()) != null){
            //process the line
            System.out.println(line);
        } */



        /*while(isGameOn){
            System.out.println(properties.getQ(count));
            count++;
        }
        */
    }



}